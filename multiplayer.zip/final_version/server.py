import socket
from _thread import start_new_thread
from modules.data_loader import load_level, load_data
import math
import random
from time import sleep


sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind(('localhost', 8889))
sock.listen()

enginedata = load_data()
lmap, lpos, linf, ldor = load_level('data/levels/3')

def generate_level():
    data = ''

    save_level = [[lmap[j][n] for n in range(len(lmap[j]))] for j in range(len(lmap))]
    obj_y_delta = 0
    for j in save_level:
        if all([n == 0 for n in j]):
            obj_y_delta -= 1
            save_level = save_level[1:]
        else:
            break
    for j in save_level[::-1]:
        if all([n == 0 for n in j]):
            save_level.pop(len(save_level) - 1)
        else:
            break
    min_x = 1000
    max_x = 0
    for j in range(len(save_level)):
        for n in range(len(save_level[j])):
            if save_level[j][n] != 0:
                min_x = min(n, min_x)
    for j in range(len(save_level)):
        for n in range(len(save_level[j]) - 1, -1, -1):
            if save_level[j][n] != 0:
                max_x = max(n, max_x)
    obj_x_delta = -min_x
    max_x += 1

    data += 'map=='
    for j in range(len(save_level)):
        save_level[j] = save_level[j][min_x:max_x]
        data += ' '.join([str(n) for n in save_level[j]]) + '\n' * (j != len(save_level) - 1)
    data += '|'
    data += 'positions=='
    for j in lpos.keys():
        for n in lpos[j]:
            data += j + ' = ' + str(n[0] + obj_x_delta) + ' ' + str(n[1] + obj_y_delta) + ' ' + str(n[2]) + '\n'
    data += '|'
    data += 'doors=='
    for j in range(len(save_level)):
        for n in range(len(save_level[j])):
            if save_level[j][n] in enginedata['doors']:
                data += str(n) + ' ' + str(j) + ' ' + str(save_level[j][n]) + ' 1\n'
    data += '|'
    data += 'info==' + 'ceiling = 125 125 125\nfloor = 80 80 80' + '&'
    return data


def make_data_recv(conn):
    data = []
    recv = ''
    while '\r\n' not in recv:
        recv += conn.recv(1024).decode()
        #if recv == '':
        #    break
    for j in recv.split('\r\n')[0].split('&'):
        if j == '':
            break
        pd = {}
        for i in j.split('|'):
            pd.update({i.split('==')[0]: i.split('==')[1]})
        data.append(pd)
    return data


def choose_spawn_point():
    player_spawn = lpos['player_sp'][random.randint(0, len(lpos['player_sp']) - 1)]
    return player_spawn


#def send(conn, text):
#    data = make_data_recv(conn)
#    conn.send(text.encode())
#    return data


def handler(conn):
    global players
    for i in range(1000):
        if players.get(i) is None:
            player_spawn = choose_spawn_point()
            reply = f'id=={i}|type==spawnpoint|x=={player_spawn[0]}|y=={player_spawn[1]}|a=={player_spawn[2]}&type==level|' + generate_level()
            for j in players.keys():
                if j != i:
                   reply += f'id=={j}|type==newplayer|name=={players[j]["name"]}|x=={players[j]["x"]}|y=={players[j]["y"]}|a=={players[j]["a"]}&'
            reply += '\r\n'
            conn.send(reply.encode())
            data = make_data_recv(conn)[0]
            players.update({i: {'conn': conn, 'x': player_spawn[0], 'y': player_spawn[1], 'a': player_spawn[2], 'name': data['name'], 'hp': 100, 'to_send': ''}})
            for j in players.keys():
                if j != i:
                    players[j]['to_send'] += f'id=={i}|type==newplayer|name=={data["name"]}|x=={player_spawn[0]}|y=={player_spawn[1]}|a=={player_spawn[2]}&'
            break
    try:
        while True:
            for i in players.keys():
                if players[i]['conn'] == conn:
                    connid = i
                    if players[i]['to_send'] == '':
                        conn.send(b'type==ping\r\n')
                    else:
                        conn.send(players[i]['to_send'][:-1].encode() + b'\r\n')
                        players[i]['to_send'] = ''
            for data in make_data_recv(conn):
                if data['type'] == 'trans':
                    players[int(data['id'])]['x'] = float(data['x'])
                    players[int(data['id'])]['y'] = float(data['y'])
                    players[int(data['id'])]['a'] = float(data['a'])
                    for i in players.keys():
                        if i != int(data['id']):
                            players[connid]['to_send'] += f'id=={i}|type==moveplayer|x=={players[i]["x"]}|y=={players[i]["y"]}|a=={players[i]["a"]}&'
                elif data['type'] == 'door':
                    ldor[int(data['door'])][3] = float(data['ratio'])
                    if float(data['ratio']) > 0.2:
                        lmap[ldor[int(data['door'])][1]][ldor[int(data['door'])][0]] = ldor[int(data['door'])][2]
                    else:
                        lmap[ldor[int(data['door'])][1]][ldor[int(data['door'])][0]] = 0
                    for i in players.keys():
                        if i != int(data['id']):
                            players[connid]['to_send'] += f'type==door|door=={data["door"]}|ratio=={data["ratio"]}&'
                elif data['type'] == 'close':
                    for i in players.keys():
                        if i != int(data['id']):
                            players[i]['to_send'] += f'id=={data["id"]}|type==close&'
                    del players[int(data['id'])]
                    #print(f'connetion with {data["id"]} {conn} succesfully closed')

    except Exception as a:
        #for i in players.keys():
        #    if i != int(data['id']):
        #        print(i)
        #        players[i]['to_send'] += f'id=={data["id"]}|type==close&'

        #print(a)
        #print(data)
        del players[int(data['id'])]
        #print(f'connetion with {data["id"]} {conn} succesfully closed')


players = {}

while True:
    conn, addr = sock.accept()
    print(1)
    start_new_thread(handler, (conn,))