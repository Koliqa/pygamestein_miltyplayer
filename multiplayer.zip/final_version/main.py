import socket
import os
import engine
import math
import pygame
import atexit
from _thread import start_new_thread


pygame.init()

print("Hey! Theres some key binds for you:\nEnter - chat\nWASD - movement\nLeft arrow/Right arrow/mouse - look\nF - fullscreen\nEscape - exit\nQ - enable/disable mouselook")
user_name = input('Username >> ')
while len(user_name) < 3 or len(user_name) > 30:
    print("Username must be bigger than 3 symbols in lenght and less than 30")
    user_name = input('Username >> ')
ip_port = ''
while ip_port not in ['0', '1']:
    ip_port = input('Enter "0" to play on the localhost or "1" to play on my dedicated server(1)\n>>')
if ip_port == '0':
    ip_port = 'localhost'
else:
    ip_port = '78.40.217.94'

def make_data_recv(conn):
    data = []
    recv = ''
    while '\r\n' not in recv:
        recv += conn.recv(1024).decode()
        #if recv == '':
        #    break
    for j in recv.split('\r\n')[0].split('&'):
        if j == '':
            break
        pd = {}
        for i in j.split('|'):
            pd.update({i.split('==')[0]: i.split('==')[1]})
        data.append(pd)
    return data


def handler(conn):
    global dummies
    #try:
        #while True:
        #    data = send_transform(conn, world.camera)
        #    if data['type'] == 'ping':
        #        pass
        #    if data['type'] == 'moveplayer':
        #        dummies[int(data['id'])]['sprite'].x = float(data['x'])
        #        dummies[int(data['id'])]['sprite'].y = float(data['y'])
        #        dummies[int(data['id'])]['sprite'].angle = float(data['a'])
    #except Exception as exc:
    #    print(exc)


def send(conn, text):
    data = make_data_recv(conn)
    conn.send(text[:-1].encode() + b'\r\n')
    return data


conn = socket.socket()
conn.connect((ip_port, 8889))

data = send(conn, f'name=={user_name}&')

os.mkdir('data/levels/temp')
map = open('data/levels/temp/map.map', 'w').write(data[1].get('map'))
positions = open('data/levels/temp/positions.pos', 'w').write(data[1].get('positions'))
doors = open('data/levels/temp/doors.dor', 'w').write(data[1].get('doors'))
info = open('data/levels/temp/info.inf', 'w').write(data[1].get('info'))
player_id = int(data[0].get('id'))

dummies = {}


def send_transform(conn, object):
    return 'id==' + str(player_id) + '|type==trans|x==' + str(object.x) + '|y==' + str(object.y) + '|a==' + str(object.angle) + '&'


def send_doors(conn, object):
    data = ''
    for i in range(len(object)):
        data += f'id=={player_id}|type==door|door=={i}|ratio=={object[i][3]}&'
    return data


def exit_handler():
    conn.send(f'id=={player_id}|type==close\r\n'.encode())
    conn.close()


atexit.register(exit_handler)


world = engine.World()
world.setup['fullscreen'] = False
world.start()
world.set_level('temp')
world.camera.x = float(data[0]['x'])
world.camera.y = float(data[0]['y'])
world.camera.angle = float(data[0]['a'])

#start_new_thread(handler, (conn,))

os.remove('data/levels/temp/map.map')
os.remove('data/levels/temp/positions.pos')
os.remove('data/levels/temp/doors.dor')
os.remove('data/levels/temp/info.inf')
os.rmdir('data/levels/temp')

if len(data) > 2:
    for i in range(2, len(data)):
        print(data)
        if data[i]['type'] != 'newplayer':
            break
        world.add_sprite('dummy', float(data[i]['x']), float(data[i]['y']), float(data[i]['a']))
        dummies.update({int(data[i]['id']): {'sprite': world.sprites[-1], 'x': float(data[i]['x']), 'y': float(data[i]['y']), 'a': float(data[i]['a']), 'name': data[i]['name'], 'hp': 100}})

pygame.mouse.set_pos(world.setup['width'] / 2, world.setup['height'] / 2)
pygame.mouse.set_visible(False)

messages = [[-1, '']]

label = pygame.font.SysFont('Consolas', 16)
writing_mode = False
text_entered = ''

src =  r"`1234567890-=qwertyuiop[]\asdfghjkl;'zxcvbnm,./"
dest = r'~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:"ZXCVBNM<>?'
mouselook = False

while True:
    to_send = ''

    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            exit()
        if i.type == pygame.KEYDOWN:
            if i.key == pygame.K_ESCAPE:
                exit()
            if i.key == pygame.K_RETURN:
                writing_mode = not writing_mode
                if not writing_mode:
                    to_send += f'id=={player_id}|type==message|message=={text_entered[:50]}&'
                    messages = [[0, 'You sent: ' + text_entered[:50]]]
                    text_entered = ''
                else:
                    messages = [[-1, '']]
            if writing_mode:
                if len(pygame.key.name(i.key)) == 1:
                    if pygame.key.get_pressed()[pygame.K_LSHIFT] or pygame.key.get_pressed()[pygame.K_RSHIFT]:
                        if pygame.key.name(i.key) in src:
                            text_entered += dest[src.index(pygame.key.name(i.key))]
                        else:
                            text_entered += pygame.key.name(i.key).upper()
                    else:
                        text_entered += pygame.key.name(i.key)
                elif pygame.key.name(i.key) == 'space':
                    text_entered += ' '
                elif pygame.key.name(i.key) == 'backspace':
                    text_entered = text_entered[:-1]
                messages[0][1] = text_entered
            else:
                if i.key == pygame.K_q:
                    mouselook = not mouselook
                if i.key == pygame.K_f:
                    pygame.display.toggle_fullscreen()

    if not writing_mode:
        if pygame.key.get_pressed()[pygame.K_w]:
            world.move_camera(0, 0.05)
        if pygame.key.get_pressed()[pygame.K_a]:
            world.move_camera(-math.pi / 2, 0.05)
        if pygame.key.get_pressed()[pygame.K_d]:
            world.move_camera(math.pi / 2, 0.05)
        if pygame.key.get_pressed()[pygame.K_s]:
            world.move_camera(math.pi, 0.05)
        if pygame.key.get_pressed()[pygame.K_LEFT]:
            world.rotate_camera(-0.02)
        if pygame.key.get_pressed()[pygame.K_RIGHT]:
            world.rotate_camera(0.02)
        if pygame.key.get_pressed()[pygame.K_SPACE]:
            res = world.open_door(world.renderer.xcam + math.cos(world.renderer.acam), world.renderer.ycam + math.sin(world.renderer.acam))
        if mouselook:
            world.rotate_camera((-world.setup['width'] / 2 + pygame.mouse.get_pos()[0]) / 5000)
            pygame.mouse.set_pos((world.setup['width'] / 2, world.setup['height'] / 2))

    #messages[0][1] = str(world.clock.get_fps())




    to_send += send_transform(conn, world.camera)# + send_doors(conn, world.level_dor)
    recv = send(conn, to_send)

    for data in recv:
        if data.get('type') == 'moveplayer':
            #print(dummies, '\n', recv)
            dummies[int(data['id'])]['sprite'].x = float(data['x'])
            dummies[int(data['id'])]['sprite'].y = float(data['y'])
            dummies[int(data['id'])]['sprite'].angle = float(data['a'])
        if data.get('type') == 'newplayer':
            world.add_sprite('dummy', float(data['x']), float(data['y']), float(data['a']))
            dummies.update({int(data['id']): {'sprite': world.sprites[-1], 'x': float(data['x']), 'y': float(data['y']), 'a': float(data['a']), 'name': data['name'], 'hp': 100}})
            messages.append([0, data['name'] + ' connected'])
        if data.get('type') == 'close':
            world.sprites.remove(dummies[int(data['id'])]['sprite'])
            messages.append([0, dummies[int(data['id'])]['name'] + ' disconnected'])
            del dummies[int(data['id'])]
        if data.get('type') == 'message':
            messages.append([0, dummies[int(data['id'])]['name'] + ' sent: ' + data.get('message')])
        #if data.get('type') == 'door':
        #    world.level_dor[int(data['door'])][3] = float(data['ratio'])
        #    if float(data['ratio']) > 0.2:
        #        world.level_map[world.level_dor[int(data['door'])][1]][world.level_dor[int(data['door'])][0]] = world.level_dor[int(data['door'])][2]
        #    else:
        #        world.level_map[world.level_dor[int(data['door'])][1]][world.level_dor[int(data['door'])][0]] = 0

    world.tick(False)

    messages[0][1] = f'players: {len(list(dummies)) + 1}'
    to_remove = []
    for i in range(len(messages)):
        text = label.render(messages[i][1], False, (0, 0, 0))
        if messages[i][0] >= 0:
            messages[i][0] += world.fps_delta
        if messages[i][0] > 100:
            to_remove.append(messages[i])
        world.display.blit(text, (0, 16 * i))
    for i in to_remove:
        messages.remove(i)

    pygame.display.update()

