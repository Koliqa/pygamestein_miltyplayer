import pygame
import math


class Renderer:
    def __init__(self, display):
        self.display = display
        self.width, self.height = display.get_size()
        self.sprites = []
        self.screen = []

    def set_tileset(self, walls, sprites, size):
        self.walls = walls
        self.spr = sprites
        self.wall_iw, self.wall_ih = walls.get_size()
        self.sprite_iw, self.sprite_ih = sprites.get_size()
        self.size = size
        self.wall_cols, self.wall_rows = self.wall_iw // size[0], self.wall_ih // size[1]
        self.sprite_cols, self.sprite_rows = self.sprite_iw // size[0], self.sprite_ih // size[1]

    def set_floor_ceiling(self, floor, ceiling):
        self.floor = floor
        self.ceiling = ceiling

    def wall_crop(self, index):
        return self.walls.subsurface((index % self.wall_cols * self.size[0],
                                      index // self.wall_cols * self.size[1],
                                      self.size[0], self.size[1]))

    def sprite_crop(self, index):
        return self.spr.subsurface((index % self.sprite_cols * self.size[0],
                                    index // self.sprite_cols * self.size[1],
                                    self.size[0], self.size[1]))

    def set_cam(self, x, y, ang, fov):
        self.xcam = x
        self.ycam = y
        self.acam = ang
        self.fov = fov
        self.fov_step = fov / self.width

    def set_cam_pos(self, x, y):
        self.xcam = x
        self.ycam = y

    def set_cam_rot(self, ang):
        self.acam = ang

    def set_cam_posrot(self, x, y, ang):
        self.xcam = x
        self.ycam = y
        self.acam = ang

    def set_level(self, level, door):
        self.level = level
        self.door = door

    def set_sprites(self, sprites):
        self.sprites = sprites

    def render_walls(self):
        screen = []

        ang = self.acam - self.fov / 2
        angleEndPoint = self.acam + self.fov / 2
        cos = .0
        sin = .0
        yx = 0;
        yy = 0;
        xx = 0;
        xy = 0
        xdir = False;
        ydir = False
        xfar = .0;
        yfar = .0
        ipx = int(self.xcam);
        ipy = int(self.ycam)
        xdel = 0;
        ydel = 0
        xside = False
        far = 0;
        obj = 0;
        cut = 0
        count = 0

        while ang < angleEndPoint:
            yfar = 0
            xfar = 0
            cos = math.cos(ang);
            sin = math.sin(ang)
            xdir = cos > 0
            ydir = sin > 0
            door_shift_y = 0
            door_shift_x = 0

            if sin:
                yy = 0
                ydel = self.ycam - ipy
                if ydir:
                    while yfar < 100.:
                        yy += 1
                        yfar = (yy - ydel) / sin
                        yx = int(self.xcam + yfar * cos)
                        if not 0 <= yy + ipy < len(self.level): yfar = 100; break
                        if not 0 <= yx < len(self.level[yy + ipy]): yfar = 100; break
                        if self.level[yy + ipy][yx] > 0:
                            is_ok = True
                            for i in self.door:
                                if yx == i[0] and yy + ipy == i[1]:
                                    if (yfar + .5 / sin) * cos + self.xcam - yx <= 1 - i[3]:
                                        is_ok = False
                                        break
                                    door_shift_y = i[3]
                                    yfar += .5 / sin
                                    break
                            if is_ok:
                                break
                            door_shift_y = 0
                else:
                    while yfar < 100.:
                        yfar = (yy - ydel) / sin
                        yy -= 1
                        yx = int(self.xcam + yfar * cos)
                        if not 0 <= yy + ipy < len(self.level): yfar = 100; break
                        if not 0 <= yx < len(self.level[yy + ipy]): yfar = 100; break
                        if self.level[yy + ipy][yx] > 0:
                            is_ok = True
                            for i in self.door:
                                if yx == i[0] and yy + ipy == i[1]:
                                    if (yfar - .5 / sin) * cos + self.xcam - yx <= 1 - i[3]:
                                        is_ok = False
                                        break
                                    door_shift_y = i[3]
                                    yfar -= .5 / sin
                                    break
                            if is_ok:
                                break
                            door_shift_y = 0
            else:
                yfar = 100.
            if cos:
                xx = 0
                xdel = self.xcam - ipx
                if xdir:
                    while xfar < 100.:
                        xx += 1
                        xfar = (xx - xdel) / cos
                        xy = int(self.ycam + xfar * sin)
                        if not 0 <= xy < len(self.level): xfar = 100; break
                        if not 0 <= xx + ipx < len(self.level[xy]): xfar = 100; break
                        if self.level[xy][xx + ipx] > 0:
                            is_ok = True
                            for i in self.door:
                                if xy == i[1] and xx + ipx == i[0]:
                                    if (xfar + .5 / cos) * sin + self.ycam - xy >= i[3]:
                                        is_ok = False
                                        break
                                    xfar += .5 / cos
                                    door_shift_x = i[3]
                                    break
                            if is_ok:
                                break
                            door_shift_x = 0
                else:
                    while xfar < 100.:
                        xfar = (xx - xdel) / cos
                        xx -= 1
                        xy = int(self.ycam + xfar * sin)
                        if not 0 <= xy < len(self.level): xfar = 100; break
                        if not 0 <= xx + ipx < len(self.level[xy]): xfar = 100; break
                        if self.level[xy][xx + ipx] > 0:
                            is_ok = True
                            for i in self.door:
                                if xy == i[1] and xx + ipx == i[0]:
                                    if (xfar - .5 / cos) * sin + self.ycam - xy >= i[3]:
                                        is_ok = False
                                        break
                                    xfar -= .5 / cos
                                    door_shift_x = i[3]
                                    break
                            if is_ok:
                                break
                            door_shift_x = 0
            else:
                xfar = 100.

            xside = xfar < yfar
            if xside:
                far = xfar
                obj = self.level[xy][xx + ipx]
                if xx + ipx < self.xcam or door_shift_x:
                    cut = self.ycam + far * sin
                    cut = int(cut) - cut + 1
                else:
                    cut = self.ycam + far * sin
                    cut = cut - int(cut)
                if door_shift_x:
                    cut = door_shift_x + cut - 1
            else:
                far = yfar
                obj = self.level[yy + ipy][yx]
                if far * sin > 0 or door_shift_y:
                    cut = self.xcam + far * cos
                    cut = int(cut) - cut + 1
                else:
                    cut = self.xcam + far * cos
                    cut = cut - int(cut)
                if door_shift_y:
                    cut = door_shift_y - cut

            screen.append([far, 0, count, ang - self.acam, obj, cut])

            ang += self.fov_step
            count += 1

        return screen

    def render_sprites(self):
        screen = []
        sx = 0.;
        sy = 0.
        sfar = 0.;
        sdir = 0.
        ssize = 0

        for i in self.sprites:
            sx = i[1]
            sy = i[2]
            sfar = math.sqrt(math.pow(self.xcam - sx, 2) + math.pow(self.ycam - sy, 2))
            if sfar != 0:

                sdir = math.atan2(sy - self.ycam, sx - self.xcam)

                while sdir - self.acam < -math.pi: sdir += math.pi * 2
                while sdir - self.acam > math.pi: sdir -= math.pi * 2

                ssize = min(2000, int(self.height / sfar))
                shor = int((sdir - self.acam + self.fov / 2) / self.fov_step - ssize / 2)

                if shor + ssize >= 0 and shor < self.width:
                    obj = i[0]
                    if type(obj) is list:
                        angle = i[3] - self.acam + math.pi / 8 + math.pi # ah, yes, magic number...

                        while angle < 0: angle += math.pi * 2
                        while angle > math.pi * 2: angle -= math.pi * 2

                        obj = obj[int(angle / (math.pi * 2 / len(obj)))]

                    screen.append([sfar, 1, obj, ssize, shor, (self.height - ssize) // 2])

        return screen

    def draw(self):
        pygame.draw.rect(self.display, self.ceiling, (0, 0, self.width, self.height // 2))
        pygame.draw.rect(self.display, self.floor, (0, self.height // 2, self.width, self.height // 2))

        screen = self.render_walls()
        screen += self.render_sprites()

        screen.sort(key=lambda i: i[0])
        screen = screen[::-1]

        for i in screen:
            if i[1] == 0:
                height = int(self.height / i[0] / math.cos(i[3]))
                if height < self.height:
                    sDraw = (self.height - height) // 2
                    sCut = 0
                    eCut = height
                else:
                    sDraw = 0
                    sCut = (height - self.height) // 2
                    eCut = self.height
                img = self.wall_crop(i[4] - 1).subsurface(int(self.size[0] * i[5]), 0, 1, self.size[1])
                img = pygame.transform.scale(img, (1, height))
                self.display.blit(img, img.get_rect(topleft=(i[2], sDraw)), (0, sCut, 1, eCut))
            if i[1] == 1:
                img = self.sprite_crop(i[2])
                img = pygame.transform.scale(img, (i[3], i[3]))
                self.display.blit(img, img.get_rect(topleft=(i[4], i[5])))

