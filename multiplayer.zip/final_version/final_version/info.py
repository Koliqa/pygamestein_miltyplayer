import math


class Nazi:
    def __init__(self, sprite, world):
        self.world = world
        self.sprite = sprite

    def tick(self, fps_delta):
        if not self.sprite.animation:
            self.sprite.set_animation([[3, 4, 5, 6, 7, 8, 9, 10],
                                       [11, 12, 13, 14, 15, 16, 17, 18],
                                       [19, 20, 21, 22, 23, 24, 25, 26],
                                       [27, 28, 29, 30, 31, 32, 33, 34],
                                       [35, 36, 37, 38, 39, 40, 41, 42]],
                                      0.1)
        if not all(self.world.move_object(0, .02, self.sprite)):
            self.world.rotate_object(math.pi, self.sprite)


objects = {
    'player': { 'active': True, 'radius': .25, 'dev_tile': 2 },
    'tree': { 'radius': .25, 'dev_tile': 0, 'tile': 0 },
    'nazi': { 'radius': .25, 'active': True, 'dev_tile': 3, 'tile': [3, 4, 5, 6, 7, 8, 9, 10], 'class': Nazi },
    'table': { 'radius': .25, 'dev_tile': 4, 'tile': 2 },
    'lamp': { 'dev_tile': 0, 'tile': 1 }
}
