import math

from modules.data_loader import *
from modules.pwen import *
import pygame
from info import *


class World:
    def __init__(self):
        global objects

        self.setup = { 'width': 640, 'height': 480, 'fullscreen': True, 'fps': 60 }
        self.enginedata = None
        self.gamedata = { 'door_speed': 0.01, 'fov': 1 }

        self.objects = objects

        self.display = None
        self.fps = None
        self.clock = pygame.time.Clock()
        self.renderer = None
        self.camera = None

        self.level_map = None
        self.level_pos = None
        self.level_inf = None
        self.level_dor = None

        self.fps_delta = 0

        self.moving_doors = []

        self.sprites = []

    def prepare_data(self):
        self.enginedata = load_data()

    def set_display(self, width=None, height=None, flags=None, fps=None):

        if width is None: width = self.setup['width']
        if height is None: height = self.setup['height']
        if flags is None: flags = pygame.FULLSCREEN * self.setup['fullscreen']
        if fps is None: fps = self.setup['fps']

        self.display = pygame.display.set_mode((width, height), flags)
        self.fps = fps

    def set_renderer(self):
        self.renderer = Renderer(self.display)

        walls = pygame.image.load(self.enginedata['walls_tile_path'])
        sprites = pygame.image.load(self.enginedata['sprites_tile_path'])
        sprites.set_colorkey(self.enginedata['colorkey'])

        self.renderer.set_tileset(walls, sprites, (self.enginedata['tile_width'], self.enginedata['tile_height']))


    def set_level(self, level_num):

        self.sprites = []

        self.level_map, self.level_pos, self.level_inf, self.level_dor = load_level('data/levels/' + level_num)

        for i in self.level_pos.keys():
            for j in self.level_pos[i]:
                self.sprites.append(Sprite(j[0], j[1], self.objects[i].get('tile'), j[2], self.objects[i].get('radius')))
                if i == self.enginedata['camera']:
                    self.camera = self.sprites[-1]
                if self.objects[i].get('class') is not None:
                    self.sprites[-1].sclass = self.objects[i]['class'](self.sprites[-1], self)
                self.sprites[-1].active = self.objects[i].get('active') is not None
                self.sprites[-1].info_name = i

        self.renderer.set_cam(self.camera.x, self.camera.y, self.camera.angle, self.gamedata['fov'])
        self.renderer.set_level(self.level_map, self.level_dor)
        self.renderer.set_floor_ceiling(self.level_inf['floor'], self.level_inf['ceiling'])

    def start(self):
        self.prepare_data()
        self.set_display()
        self.set_renderer()

    def tick(self, update_display=True):
        if self.clock.get_fps():
            self.fps_delta = self.enginedata['base_fps'] / self.clock.get_fps()
        else:
            self.fps_delta = 0

        for i in self.sprites:
            if i.sclass is not None:
                i.sclass.tick(self.fps_delta)
            i.animation_tick(self.fps_delta)
        self.renderer.set_sprites([[i.tile, i.x, i.y, i.angle] if type(i.tile) is list else [i.tile, i.x, i.y] for i in self.sprites if i.tile is not None])
        stop_moving = []

        for i in self.moving_doors:
            self.level_dor[i[0]][3] += i[1] * self.fps_delta * self.gamedata['door_speed']
            if self.level_dor[i[0]][3] < 0:
                self.level_dor[i[0]][3] = 0
                self.level_map[self.level_dor[i[0]][1]][self.level_dor[i[0]][0]] = 0
                stop_moving.append(i)
            if self.level_dor[i[0]][3] > 1:
                self.level_dor[i[0]][3] = 1
                stop_moving.append(i)

        for i in stop_moving:
            self.moving_doors.remove(i)

        self.renderer.set_cam_posrot(self.camera.x, self.camera.y, self.camera.angle)

        self.renderer.draw()

        if update_display:
            pygame.display.update()

        self.clock.tick(self.fps)

    def open_door(self, x, y):
        x = int(x)
        y = int(y)
        for i in range(len(self.level_dor)):
            if x == self.level_dor[i][0] and y == self.level_dor[i][1] and (self.level_dor[i][3] == 0 or self.level_dor[i][3] == 1):
                all_ok = True
                if self.level_map[self.level_dor[i][1]][self.level_dor[i][0]]:
                    self.moving_doors.append([i, -1])
                else:
                    self.level_map[y][x] = self.level_dor[i][2]
                    for j in self.sprites:
                        if j.radius is not None and j.active:
                            all_ok = self.move_object(0, 0, j, False)
                            all_ok = all_ok[0] or all_ok[1]
                            if not all_ok:
                                break
                    if not all_ok:
                        self.level_map[y][x] = 0
                    else:
                        self.moving_doors.append([i, 1])
                if all_ok:
                    return True
        return False


    def move_camera(self, angle_delta, speed):
        return self.move_object(angle_delta, speed, self.camera)

    def rotate_camera(self, angle_delta):
        self.rotate_object(angle_delta, self.camera)

    def rotate_object(self, angle_delta, object):
        if self.clock.get_fps():
            object.angle += angle_delta
        while object.angle > math.pi: object.angle -= math.pi * 2
        while object.angle < -math.pi: object.angle += math.pi * 2

    def move_object(self, angle_delta, speed, object, move=True):
        if not self.clock.get_fps():
            return False, False

        nx, ny = object.x + speed * math.cos(object.angle + angle_delta) * self.fps_delta, object.y + speed * math.sin(object.angle + angle_delta) * self.fps_delta

        for i in self.sprites:
            if i != object and i.radius is not None:
                distance = ((i.x - object.x) ** 2 + (i.y - object.y) ** 2) ** .5
                if distance < i.radius + object.radius:
                    dist_ang = math.atan2(i.y - object.y, i.x - object.x)
                    nx = nx + math.cos(dist_ang) * (distance - i.radius - object.radius)
                    ny = ny + math.sin(dist_ang) * (distance - i.radius - object.radius)

        if self.level_map[int(ny)][int(nx)]:
            return False, False

        if not self.level_map[int(ny + object.radius)][int(nx + object.radius)] and \
                not self.level_map[int(ny - object.radius)][int(nx + object.radius)] and \
                not self.level_map[int(ny + object.radius)][int(nx - object.radius)] and \
                not self.level_map[int(ny - object.radius)][int(nx - object.radius)]:
            if move:
                object.x = nx
                object.y = ny
            return True, True

        if not self.level_map[int(ny + object.radius)][int(object.x + object.radius)] and \
                not self.level_map[int(ny - object.radius)][int(object.x + object.radius)] and \
                not self.level_map[int(ny + object.radius)][int(object.x - object.radius)] and \
                not self.level_map[int(ny - object.radius)][int(object.x - object.radius)]:
            if move:
                object.y = ny
            return False, True

        if not self.level_map[int(object.y + object.radius)][int(nx + object.radius)] and \
                not self.level_map[int(object.y - object.radius)][int(nx + object.radius)] and \
                not self.level_map[int(object.y + object.radius)][int(nx - object.radius)] and \
                not self.level_map[int(object.y - object.radius)][int(nx - object.radius)]:
            if move:
                object.x = nx
            return True, False

        return False, False


class Sprite:
    def __init__(self, x, y, tile=None, angle=0, radius=0, active=False, info_name=None):
        self.x = x
        self.y = y
        self.tile = tile
        self.angle = angle
        self.radius = radius
        self.animation = []
        self.sclass = None
        self.active = active
        self.info_name = info_name

    def set_animation(self, frames, speed):
        self.animation = [frames, speed, 0]

    def animation_tick(self, fps_delta):
        if not self.animation:
            return
        self.animation[2] += self.animation[1] * fps_delta
        if self.animation[2] >= len(self.animation[0]):
            self.animation[2] = 0
        self.tile = self.animation[0][int(self.animation[2])]