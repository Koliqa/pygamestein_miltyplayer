import engine
import math
import pygame


world = engine.World()
world.start()
world.set_level('4')

pygame.mouse.set_pos(world.setup['width'] / 2, world.setup['height'] / 2)
pygame.mouse.set_visible(False)

while True:
    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            exit()
        if i.type == pygame.KEYDOWN:
            if i.key == pygame.K_ESCAPE:
                exit()

    if pygame.key.get_pressed()[pygame.K_w]:
        world.move_camera(0, 0.05)
    if pygame.key.get_pressed()[pygame.K_a]:
        world.move_camera(-math.pi / 2, 0.05)
    if pygame.key.get_pressed()[pygame.K_d]:
        world.move_camera(math.pi / 2, 0.05)
    if pygame.key.get_pressed()[pygame.K_s]:
        world.move_camera(math.pi, 0.05)
    if pygame.key.get_pressed()[pygame.K_LEFT]:
        world.rotate_camera(-0.02)
    if pygame.key.get_pressed()[pygame.K_RIGHT]:
        world.rotate_camera(0.02)

    if pygame.key.get_pressed()[pygame.K_SPACE]:
        world.open_door(world.renderer.xcam + math.cos(world.renderer.acam), world.renderer.ycam + math.sin(world.renderer.acam))

    world.rotate_camera(pygame.mouse.get_rel()[0] / 1000)
    pygame.mouse.set_pos((world.setup['width'] / 2, world.setup['height'] / 2))

    world.tick()
