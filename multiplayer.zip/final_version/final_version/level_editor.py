import os
from modules.data_loader import *

import math
import pygame

from info import objects


width, height = 800, 600

display = pygame.display.set_mode((width, height))

tiles_row = 8

tile_resize = 32



# LOAD DATA

enginedata_file = open('data/enginedata.ed').read().split('\n')
enginedata = {}

for i in enginedata_file:
    if i == '':
        break
    if len(i.split(' = ')[1].split()) != 1:
        enginedata_arr = []
        try:
            if '.' in i.split(' = ')[1].split()[0]:
                for j in i.split(' = ')[1].split():
                    enginedata_arr.append(float(j))
            else:
                for j in i.split(' = ')[1].split():
                    enginedata_arr.append(int(j))
        except ValueError:
            for j in i.split(' = ')[1].split():
                enginedata_arr.append(j)
        enginedata.update({i.split(' = ')[0]: enginedata_arr})

    else:
        try:
            if '.' in i.split(' = ')[1]:
                enginedata.update({i.split(' = ')[0]: float(i.split(' = ')[1])})
            else:
                enginedata.update({i.split(' = ')[0]: int(i.split(' = ')[1])})
        except ValueError:
            enginedata.update({i.split(' = ')[0]: i.split(' = ')[1]})

del enginedata_file

# ---

if type(enginedata['doors']) is int:
    enginedata['doors'] = [enginedata['doors']]

pygame.font.init()

wall_texture = pygame.image.load(enginedata['walls_tile_path'])

wall_texture_old_size = wall_texture.get_size()
wall_texture = pygame.transform.scale(wall_texture, (width, wall_texture_old_size[1] / (wall_texture_old_size[0] / width)))
wall_col = (wall_texture_old_size[1] / enginedata['tile_height'])
wall_row = (wall_texture_old_size[0] / enginedata['tile_width'])
wall_menu_size = width / wall_row, wall_texture_old_size[1] / (wall_texture_old_size[0] / width) / wall_col

dev_tile = pygame.image.load(enginedata['dev_tile_path'])
dev_texture_old_size = dev_tile.get_size()
dev_tile.set_colorkey(enginedata['colorkey'])
dev_tile = pygame.transform.scale(dev_tile, (width, dev_texture_old_size[1] / (dev_texture_old_size[0] / width)))
dev_col = (dev_texture_old_size[1] / enginedata['tile_height'])
dev_row = (dev_texture_old_size[0] / enginedata['tile_width'])
dev_menu_size = width / dev_row, dev_texture_old_size[1] / (dev_texture_old_size[0] / width) / dev_col

menu = ['New', 'Load', 'Exit']

menu_choise = 0
menu_camera = 0
font = pygame.font.SysFont('Consolas', 36)
data_font = pygame.font.SysFont('Consolas', 14)

clock = pygame.time.Clock()

level = []
positions = {}

x, y = 500 * tile_resize, 500 * tile_resize
move_speed = 4
scrolling_speed = 8

action = 'menu'

choosing_y = 0

current_object = 'wall 1'
dev_tile_rotation = 0
loaded_level_name = False

while True:
    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            exit()
        if menu:
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_UP:
                    menu_choise -= 1
                    if menu_choise < 0:
                        menu_choise = len(menu) - 1
                if i.key == pygame.K_DOWN:
                    menu_choise += 1
                    if menu_choise >= len(menu):
                        menu_choise = 0
                if i.key == pygame.K_RETURN:
                    if menu[menu_choise] == 'New':
                        loaded_level_name = False
                        menu = []
                        positions = {}
                        level = [[0 for j in range(1000)] for i in range(1000)]
                        action = 'editing'
                        menu_camera = 0
                    elif menu[menu_choise] == 'Load':
                        menu = ['Level: ' + i for i in os.listdir('data/levels')]
                        menu_choise = 0
                    elif menu[menu_choise] == 'Exit':
                        exit()
                    elif menu[menu_choise].startswith('Level: '):
                        action = 'editing'
                        menu_camera = 0
                        loaded_level_name = 'data/levels/' + menu[menu_choise][7:]
                        loaded_level = load_level('data/levels/' + menu[menu_choise][7:])
                        level = loaded_level[0]
                        obj_x_delta = math.ceil((1000 - len(level[0])) / 2)
                        obj_y_delta = math.ceil((1000 - len(level)) / 2)
                        while len(level) < 1000:
                            level.insert(0, [0 for j in range(1000)])
                            level.append([0 for j in range(1000)])
                        for j in range(len(level)):
                            while len(level[j]) < 1000:
                                level[j] = [0, *level[j], 0]
                        menu = []
                        positions = loaded_level[1]
                        for j in positions.keys():
                            for n in positions[j]:
                                n[2] = -n[2] - math.pi / 2
                        for j in positions.keys():
                            for n in range(len(positions[j])):
                                positions[j][n][0] += obj_x_delta
                                positions[j][n][1] += obj_y_delta
                    elif menu[menu_choise] == 'Continue':
                        menu = []
                    elif menu[menu_choise] == 'Save':
                        if loaded_level_name:
                            filepath = loaded_level_name.split('/')[-1]
                        else:
                            if os.listdir('data/levels'):
                                filepath = str(int(os.listdir('data/levels')[-1]) + 1)
                            else:
                                filepath = '1'
                            os.mkdir('data/levels/' + filepath)
                        menu = []
                        save_level = [[level[j][n] for n in range(len(level[j]))] for j in range(len(level))]
                        obj_y_delta = 0
                        for j in save_level:
                            if all([n == 0 for n in j]):
                                obj_y_delta -= 1
                                save_level = save_level[1:]
                            else:
                                break
                        for j in save_level[::-1]:
                            if all([n == 0 for n in j]):
                                save_level.pop(len(save_level) - 1)
                            else:
                                break
                        min_x = 1000
                        max_x = 0
                        for j in range(len(save_level)):
                            for n in range(len(save_level[j])):
                                if save_level[j][n] != 0:
                                    min_x = min(n, min_x)
                        for j in range(len(save_level)):
                            for n in range(len(save_level[j]) - 1, -1, -1):
                                if save_level[j][n] != 0:
                                    max_x = max(n, max_x)
                        obj_x_delta = -min_x
                        max_x += 1
                        file_map = open('data/levels/' + filepath + '/map.map', 'w')
                        file_positions = open('data/levels/' + filepath + '/positions.pos', 'w')
                        file_doors = open('data/levels/' + filepath + '/doors.dor', 'w')
                        file_info = open('data/levels/' + filepath + '/info.inf', 'w')

                        for j in range(len(save_level)):
                            save_level[j] = save_level[j][min_x:max_x]
                            file_map.write(' '.join([str(n) for n in save_level[j]]) + '\n' * (j != len(save_level) - 1))
                        for j in positions.keys():
                            for n in positions[j]:
                                file_positions.write(j + ' = ' + str(n[0] + obj_x_delta) + ' ' + str(n[1] + obj_y_delta) + ' ' + str(-n[2] - math.pi / 2) + '\n')
                        for j in range(len(save_level)):
                            for n in range(len(save_level[j])):
                                if save_level[j][n] in enginedata['doors']:
                                    file_doors.write(str(n) + ' ' + str(j) + ' ' + str(save_level[j][n]) + ' 1\n')
                        file_info.write('ceiling = 125 125 125\nfloor = 80 80 80')

                        file_map.close()
                        file_positions.close()
                        file_doors.close()
                        file_info.close()

                if i.key == pygame.K_ESCAPE:
                    if level == []:
                        menu_choise = 0
                        menu = ['New', 'Load', 'Exit']
                    else:
                        if menu == ['Continue', 'Save', 'New', 'Load', 'Exit']:
                            menu = []
                            action = 'editing'
                            menu_camera = 0
                        else:
                            menu_choise = 0
                            menu = ['Continue', 'Save', 'New', 'Load', 'Exit']
        else:
            if i.type == pygame.KEYDOWN:
                if i.key == pygame.K_ESCAPE:
                    if level == []:
                        menu_choise = 0
                        menu = ['New', 'Load']
                    else:
                        if menu == ['Continue', 'Save', 'New', 'Load', 'Exit']:
                            menu = []
                            action = 'editing'
                            menu_camera = 0
                        else:
                            menu_choise = 0
                            menu = ['Continue', 'Save', 'New', 'Load', 'Exit']
                if i.key == pygame.K_w:
                    choosing_y = 0
                    if action == 'choosing wall texture':
                        action = 'editing'
                    else:
                        action = 'choosing wall texture'
                if i.key == pygame.K_d:
                    choosing_y = 0
                    dev_tile_rotation = 0
                    if action == 'choosing dev texture':
                        action = 'editing'
                    else:
                        action = 'choosing dev texture'
            if i.type == pygame.MOUSEBUTTONUP and action == 'choosing wall texture':
                if i.button == 1 and wall_texture_num is not None:
                    current_object = 'wall ' + str(wall_texture_num + 1)
                    action = 'editing'
            if i.type == pygame.MOUSEBUTTONUP and action == 'choosing dev texture':
                if i.button == 1 and dev_tile_num is not None:
                    current_object = 'dev ' + str(dev_tile_num)
                    action = 'editing'
            if i.type == pygame.MOUSEWHEEL:
                if current_object.split()[0] == 'dev':
                    if pygame.key.get_pressed()[pygame.K_LSHIFT]:
                        dev_tile_rotation += i.y * 0.1 * 60 / clock.get_fps()
                    else:
                        dev_tile_rotation += i.y * math.pi / 4
                if dev_tile_rotation <= -math.pi:
                    dev_tile_rotation += math.pi * 2
                if dev_tile_rotation >= math.pi:
                    dev_tile_rotation -= math.pi * 2

    display.fill((0, 0, 0))

    if menu:
        for i in range(len(menu)):
            text = menu[i]
            if i == menu_choise:
                text = '> ' + text + ' <'
                if height // 2 - 36 * len(menu) // 2 + 36 * i + menu_camera - 18 < 0:
                    menu_camera += 36
                if height // 2 - 36 * len(menu) // 2 + 36 * i + menu_camera + 18 > height:
                    menu_camera -= 36
            label = font.render(text, True, (255, 255, 255))
            display.blit(label, label.get_rect(center=(width // 2, height // 2 - 36 * len(menu) // 2 + 36 * i + menu_camera)))

    else:

        if action == 'editing':

            if pygame.mouse.get_pressed()[0]:
                xx, yy = pygame.mouse.get_pos()
                if current_object.split()[0] == 'wall':
                    level[int(yy + y) // tile_resize][int(xx + x) // tile_resize] = int(current_object.split()[1])
                if current_object.split()[0] == 'dev':
                    allok = True
                    for i in positions.keys():
                        for j in range(len(positions[i])):
                            if (positions[i][j][0] == int(xx + x) // tile_resize + .5 and positions[i][j][1] == int(yy + y) // tile_resize + .5) or level[int(yy + y) // tile_resize][int(xx + x) // tile_resize]:
                                allok = False
                                break
                        if not allok:
                            break
                    if allok:
                        for i in objects.keys():
                            if dev_tile_num == objects[i]['dev_tile']:
                                if positions.get(i) is None:
                                    positions.update({i: [[int(xx + x) // tile_resize + .5, int(yy + y) // tile_resize + .5, dev_tile_rotation]]})
                                else:
                                    positions[i].append([int(xx + x) // tile_resize + .5, int(yy + y) // tile_resize + .5, dev_tile_rotation])

            if pygame.mouse.get_pressed()[2]:
                xx, yy = pygame.mouse.get_pos()
                level[int(yy + y) // tile_resize][int(xx + x) // tile_resize] = 0
                allok = True
                for i in positions.keys():
                    for j in range(len(positions[i])):
                        if positions[i][j][0] == int(xx + x) // tile_resize + .5 and positions[i][j][1] == int(yy + y) // tile_resize + .5:
                            del positions[i][j]
                            allok = False
                            break
                    if not allok:
                        break

            if pygame.key.get_pressed()[pygame.K_UP]:
                y -= move_speed * 60 / clock.get_fps()
                if y < 0:
                    y = 0

            if pygame.key.get_pressed()[pygame.K_DOWN]:
                y += move_speed * 60 / clock.get_fps()
                if y < height - tile_resize:
                    y = height - tile_resize

            if pygame.key.get_pressed()[pygame.K_LEFT]:
                x -= move_speed * 60 / clock.get_fps()
                if x < 0:
                    x = 0

            if pygame.key.get_pressed()[pygame.K_RIGHT]:
                x += move_speed * 60 / clock.get_fps()
                if x < width - tile_resize:
                    x = width - tile_resize

            y_shift = y // tile_resize * tile_resize - y
            x_shift = x // tile_resize * tile_resize - x

            yyd = y_shift
            xxd = x_shift
            for iy in level[int(y / tile_resize): int(y / tile_resize) + int(height / tile_resize) + 2]:
                for ix in iy[int(x / tile_resize): int(x / tile_resize) + int(width / tile_resize) + 1]:
                    if ix:
                        wall_tile = wall_texture.subsurface(((ix - 1) % wall_row * wall_menu_size[0], (ix - 1) // wall_row * wall_menu_size[1], wall_menu_size[0], wall_menu_size[1]))
                        wall_tile = pygame.transform.scale(wall_tile, (tile_resize, tile_resize))
                        display.blit(wall_tile, wall_tile.get_rect(topleft=(xxd, yyd)))

                    xxd += tile_resize
                yyd += tile_resize
                xxd = x_shift

            for i in positions.keys():
                for j in positions[i]:
                    tile = dev_tile.subsurface(((objects[i]['dev_tile'] % dev_row * dev_menu_size[0], objects[i]['dev_tile'] // dev_row * dev_menu_size[1], dev_menu_size[0], dev_menu_size[1])))
                    tile = pygame.transform.scale(tile, (tile_resize, tile_resize))
                    tile = pygame.transform.rotate(tile, math.degrees(j[2]))
                    display.blit(tile, tile.get_rect(topleft=(int(j[0]) * tile_resize - x - (tile.get_width() - tile_resize) / 2, int(j[1]) * tile_resize - y - (tile.get_height() - tile_resize) / 2)))

            for yy in range(-1, height // tile_resize + 2):
                pygame.draw.line(display, (128, 128, 128), (0, yy * tile_resize + y_shift), (width, yy * tile_resize + y_shift))

            for xx in range(-1, width // tile_resize + 2):
                pygame.draw.line(display, (128, 128, 128), (xx * tile_resize + x_shift, 0), (xx * tile_resize + x_shift, height))

            text = f'{int(x)}:{int(y)}'
            label = data_font.render(text, True, (255, 255, 255))
            display.blit(label, label.get_rect(topleft=(2, height - 16)))

            if current_object.split()[0] == 'wall':
                wall_texture_num = int(current_object.split()[1]) - 1
                width_cut = wall_texture_num % wall_row * wall_menu_size[0]
                height_cut = wall_texture_num // wall_row * wall_menu_size[1]
                wall_result = wall_texture.subsurface((width_cut, height_cut, wall_menu_size[0], wall_menu_size[1]))
                wall_result = pygame.transform.scale(wall_result, (enginedata['tile_width'], enginedata['tile_height']))
                display.blit(wall_result, wall_result.get_rect(topleft=(width - 10 - enginedata['tile_width'], height - 10 - enginedata['tile_height'])))
            if current_object.split()[0] == 'dev':
                dev_tile_num = int(current_object.split()[1])
                width_cut = dev_tile_num % dev_row * dev_menu_size[0]
                height_cut = dev_tile_num // dev_row * dev_menu_size[1]
                tile = dev_tile.subsurface((width_cut, height_cut, dev_menu_size[0], dev_menu_size[1]))
                tile = pygame.transform.rotate(tile, math.degrees(float(dev_tile_rotation)))
                tile = pygame.transform.scale(tile, (enginedata['tile_width'], enginedata['tile_height']))
                display.blit(tile, tile.get_rect(topleft=(width - 10 - enginedata['tile_width'] - (tile.get_width() - tile_resize) / 2, height - 10 - enginedata['tile_height'] - (tile.get_height() - tile_resize) / 2)))
                label = data_font.render('rotation: ' + str(math.degrees(dev_tile_rotation)), True, (128, 128, 128))
                display.blit(label, label.get_rect(topleft=(width - 150, height - 20)))
        if action == 'choosing wall texture':
            if pygame.key.get_pressed()[pygame.K_UP]:
                choosing_y += scrolling_speed * 60 / clock.get_fps()
            if pygame.key.get_pressed()[pygame.K_DOWN]:
                choosing_y -= scrolling_speed * 60 / clock.get_fps()
            display.blit(wall_texture, wall_texture.get_rect(topleft=(0, choosing_y)))

            wall_texture_num = int(pygame.mouse.get_pos()[0] // wall_menu_size[0] + (pygame.mouse.get_pos()[1] - choosing_y) // wall_menu_size[1] * wall_row)
            if wall_texture_num < 0:
                wall_texture_num = None

            text = f'{int(-choosing_y)}:{wall_texture_num}'
            label = data_font.render(text, True, (255, 255, 255))
            display.blit(label, label.get_rect(topleft=(2, height - 16)))
        if action == 'choosing dev texture':
            if pygame.key.get_pressed()[pygame.K_UP]:
                choosing_y += scrolling_speed * 60 / clock.get_fps()
            if pygame.key.get_pressed()[pygame.K_DOWN]:
                choosing_y -= scrolling_speed * 60 / clock.get_fps()
            display.blit(dev_tile, dev_tile.get_rect(topleft=(0, choosing_y)))

            dev_tile_num = int(pygame.mouse.get_pos()[0] // dev_menu_size[0] + (pygame.mouse.get_pos()[1] - choosing_y) // dev_menu_size[1] * dev_row)
            if dev_tile_num < 0:
                dev_tile_num = None

            text = f'{int(-choosing_y)}:{dev_tile_num}'
            label = data_font.render(text, True, (255, 255, 255))
            display.blit(label, label.get_rect(topleft=(2, height - 16)))

    pygame.display.update()
    clock.tick(60)